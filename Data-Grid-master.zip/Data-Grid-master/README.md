# Data-Grid
Get Data from SQL Database and display to Data Grid using ADO .Net C# in Asp .Net Core (MVC)

Tutorial Link: https://youtu.be/s3o8iuoDMyI

Channel Link: www.youtube.com/c/oopcoreconcepts
